
import java.awt.Graphics2D;
import java.util.Random;
import java.awt.Color;
import java.awt.Rectangle;

class NotIT implements Player {
    private double x, y;
    private final int radius = 15;
    private double speed = 3;
    private final int panelWidth, panelHeight;
    private final Random random = new Random();

    public NotIT(int startX, int startY, int panelWidth, int panelHeight) {
        this.x = startX;
        this.y = startY;
        this.panelWidth = panelWidth;
        this.panelHeight = panelHeight;
    }

    public void moveAway(Player it) {
        double dx = x - it.getX();
        double dy = y - it.getY();
        double distance = Math.sqrt(dx * dx + dy * dy);

        double vx = 0, vy = 0;

        if (distance > 0.001) {
            vx = (dx / distance) * speed;
            vy = (dy / distance) * speed;
        } else { // Random small jump if too close
            vx = ((random.nextDouble() - 0.5) * 2) * speed;
            vy = ((random.nextDouble() - 0.5) * 2) * speed;
        }

        // randomness so they don't move the same
        vx += (random.nextDouble() - 0.5) * 0.5;
        vy += (random.nextDouble() - 0.5) * 0.5;

        x += vx;
        y += vy;

        // boundary checks
        if (x < radius) x = radius + random.nextDouble() * 3;
        if (y < radius) y = radius + random.nextDouble() * 3;
        if (x > panelWidth - radius) x = panelWidth - radius - random.nextDouble() * 3;
        if (y > panelHeight - radius) y = panelHeight - radius - random.nextDouble() * 3;
    }

    @Override
    public void update() {
        x += (random.nextDouble() - 0.5) * 0.5;
        y += (random.nextDouble() - 0.5) * 0.5;

        if (x < radius) x = radius;
        if (y < radius) y = radius;
        if (x > panelWidth - radius) x = panelWidth - radius;
        if (y > panelHeight - radius) y = panelHeight - radius;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(Color.BLUE);
        g.fillOval((int)(x - radius), (int)(y - radius), radius * 2, radius * 2);
        g.setColor(Color.WHITE);
    }

    @Override
    public int getX() { return (int)Math.round(x); }

    @Override
    public int getY() { return (int)Math.round(y); }

    @Override
    public int getRadius() { return radius; }

    @Override
    public Rectangle getBounds() {
        return new Rectangle((int)(x - radius), (int)(y - radius), radius * 2, radius * 2);
    }

    @Override
    public void move(int direction) {
        // Implement a simple move if needed, or leave empty if not used
        // For example, move randomly:
        x += (random.nextDouble() - 0.5) * speed;
        y += (random.nextDouble() - 0.5) * speed;

        // boundary checks
        if (x < radius) x = radius;
        if (y < radius) y = radius;
        if (x > panelWidth - radius) x = panelWidth - radius;
        if (y > panelHeight - radius) y = panelHeight - radius;
    }

    public boolean isTaggedBY(Player it) {
        double dx = x - it.getX();
        double dy = y - it.getY();
        double distanceSq = dx * dx + dy * dy;
        double combinedRadius = radius + it.getRadius() * 0.9;
        return distanceSq <= combinedRadius * combinedRadius;
    }
}