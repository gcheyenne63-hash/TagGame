import java.awt.Desktop;
import javax.sound.sampled.AudioInputStream;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.Timer;

class DirectAction extends AbstractAction {
    private final int direction;
    private final boolean press;
    private final GamePanel gamePanel;
    private boolean running;
    private int score;
    private int timeLeft;
    private static final int GAME_DURATION_SEC = 60;
    private Timer gameTimer;
    private Timer countdownTimer;

    DirectAction(int direction, boolean press, GamePanel gamePanel) {
        this.direction = direction;
        this.press = press;
        this.gamePanel = gamePanel;
    }

    private void updateScoreLabel() {
        // stub: implement UI score update if needed
    }

    private void updateTimeLabel() {
        // stub: implement UI time update if needed
    }

    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if (press) {
            gamePanel.getItPlayer().setDirection(direction);
        } else {
            gamePanel.getItPlayer().stopMoving();
        }
    }

    private void startGame() {
        if (running) {
            return;
        }
        running = true;
        updateScoreLabel();
        updateTimeLabel();
        gamePanel.resetPlayers();
        gameTimer.start();
        countdownTimer.start();
    }

    private void restartGame() {
        gameTimer.stop();
        countdownTimer.stop();
        running = false;
        startGame();
    }

    private void tagged(NotIt taggedRunner) {
        if (!running) return;
        score++;
        updateScoreLabel();
        taggedRunner = gamePanel.respawnRunner(taggedRunner);
    }

    private void endGame() {
        gameTimer.stop();
        countdownTimer.stop();
        running = false;
        JOptionPane.showMessageDialog(null, "Time's up! Your score: " + score);
    }
}

public void resetPlayers() {
    // Implement logic to reset player positions and states as needed
}